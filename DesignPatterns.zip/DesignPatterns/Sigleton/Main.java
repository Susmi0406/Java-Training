public class Main {
public static void main(String args[]) {
	
		 
    HealthChecker healthChecker = HealthChecker.getHealthChecker();
    healthChecker.print();
    
    HealthChecker healthChecker1 = HealthChecker.getHealthChecker();
    healthChecker1.print();
    
    
}
}