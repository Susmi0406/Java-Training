public class ReligionBook implements Library{
    @Override
    public String bookType() {
        return "Quran (given to Muhammad), the Torah (given to Moses), the Gospel (given to Jesus), the Psalms (given to David), and the Scrolls (given to Abraham).";
    }
    
}
