public class StoryBook implements Library {
    @Override
    public String bookType() {
        return "The Little Prince, Jane Eyre, Little Women, A Horseman in the Sky";
    }
    
}

