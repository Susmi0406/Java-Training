public class NewsPaper implements Library {
    @Override

    public String bookType() {
        return "Daily Mirror, LankaSri, Veerakesari, Thinakural";
    }
}
