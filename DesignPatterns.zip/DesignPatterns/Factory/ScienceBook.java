public class ScienceBook implements Library {
    @Override

    public String bookType() {
        return "The Origin of Species, The Strange Theory of Light and Matter, On Growth and Form, Ideas And Opinions";
    }
}
