public interface Library {
    public String bookType() ;
}
